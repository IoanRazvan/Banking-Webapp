create
    definer = doadmin@`%` procedure UPDATE_MAIN_ACCOUNT(IN owner_id int, IN account_id int)
BEGIN 
    UPDATE CONT SET main_account = FALSE WHERE (main_account = TRUE and BANK_ACCOUNT.owner_id = owner_id);
    UPDATE CONT SET main_account = TRUE WHERE (BANK_ACCOUNT.owner_id = owner_id and BANK_ACCOUNT.account_id = account_id);
  END;

